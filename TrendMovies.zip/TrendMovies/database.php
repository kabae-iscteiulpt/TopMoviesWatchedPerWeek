<?php

//to connect with database
$conn = new PDO('mysql: host=127.0.0.1;dbname=TrendMovies;port=3306','root');
?>